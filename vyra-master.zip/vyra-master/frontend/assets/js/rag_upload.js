/**
 * RAG Upload Module
 * Dosya yükleme ve bilgi tabanı yönetimi
 */

const RAGUpload = {
    // API Base URL
    API_BASE: (window.API_BASE_URL || 'http://localhost:8002') + '/api',

    // State
    isUploading: false,
    files: [],
    stats: {
        fileCount: 0,
        chunkCount: 0,
        status: 'Hazır'
    },
    selectedOrgIds: [],  // Seçilen org grupları
    orgs: [],            // Tüm org grupları

    // Upload Flow States
    pendingFiles: null,              // Org seçimi bekleyen dosyalar
    shouldOpenFileDialogAfterOrg: false, // Org seçiminden sonra dosya diyaloğu açılsın mı?

    // Files pagination & search
    filesCurrentPage: 1,
    filesPerPage: 10,
    filesTotalCount: 0,
    filesSearchTerm: '',

    /**
     * Modülü başlatır
     */
    async init() {
        console.log('[RAGUpload] Modül başlatılıyor...');

        this.setupDragAndDrop();
        this.setupFileInput();
        this.setupEventListeners();

        await this.loadOrgs();   // Org gruplarını yükle
        await this.loadMaturityThreshold(); // Eşik değerini yükle
        await this.loadFiles();
        await this.loadStats();

        console.log('[RAGUpload] Modül hazır.');
    },

    /**
     * Drag & Drop işlevselliği
     */
    setupDragAndDrop() {
        const dropZone = document.getElementById('rag-upload-zone');
        if (!dropZone) return;

        // Duplicate listener koruması - init() birden fazla çağrılsa bile tekrar ekleme
        if (dropZone.hasAttribute('data-drop-listener-added')) return;
        dropZone.setAttribute('data-drop-listener-added', 'true');

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => {
                dropZone.classList.add('drag-over');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => {
                dropZone.classList.remove('drag-over');
            });
        });

        dropZone.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length) {
                this.handleFiles(files);
            }
        });

        // dropZone tıklandığında - ÖNCELİKLE ORG KONTROLÜ YAP
        dropZone.addEventListener('click', (e) => {
            // File input element'ine veya içine tıklandıysa native davranış devam etsin
            if (e.target.closest('#rag-file-input') || e.target.id === 'rag-file-input') {
                return;
            }

            // 🔒 ORG KONTROLÜ - En başta tek yerde yap
            if (!this.selectedOrgIds || this.selectedOrgIds.length === 0) {
                e.preventDefault();
                e.stopPropagation();
                // Toast kaldırıldı - Sadece modal açılacak
                this.shouldOpenFileDialogAfterOrg = true; // Org seçiminden sonra dialog aç
                this.openOrgModal();
                return;
            }

            // Org seçiliyse file input'u programatik tetikle
            const fileInput = document.getElementById('rag-file-input');
            if (fileInput) {
                fileInput.click();
            }
        });
    },

    /**
     * File input işlevselliği
     */
    setupFileInput() {
        const fileInput = document.getElementById('rag-file-input');
        if (!fileInput) return;

        // Event listener zaten ekliyse tekrar ekleme
        if (fileInput.hasAttribute('data-listener-added')) return;
        fileInput.setAttribute('data-listener-added', 'true');

        // Org kontrolü handleFiles'da yapılıyor, burada tekrar yapmıyoruz
        fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files.length > 0) {
                this.handleFiles(e.target.files);
            }
        });
    },

    /**
     * Event listener'lar (sadece bir kez bağlanır)
     */
    setupEventListeners() {
        // Duplicate protection — init() her tab geçişinde çağrılıyor
        if (this._listenersAttached) return;
        this._listenersAttached = true;

        // Rebuild butonu
        const rebuildBtn = document.getElementById('btn-rebuild-vectorstore');
        if (rebuildBtn) {
            rebuildBtn.addEventListener('click', () => this.rebuildVectorstore());
        }

        // Maturity threshold slider
        const thresholdSlider = document.getElementById('rag-maturity-threshold');
        if (thresholdSlider) {
            thresholdSlider.addEventListener('input', (e) => {
                const val = e.target.value;
                const label = document.getElementById('rag-threshold-value');
                if (label) label.textContent = val;
            });
            thresholdSlider.addEventListener('change', (e) => {
                this.saveMaturityThreshold(parseInt(e.target.value, 10));
            });
        }
    },

    // --- ORG MODAL ---
    // v2.30.1: modules/rag_org_modal.js modülüne taşındı.
    // Delegation: window.RAGOrgModal
    loadOrgs() { if (window.RAGOrgModal) window.RAGOrgModal.loadOrgs.call(this); },
    saveSelectedOrgsToStorage() { if (window.RAGOrgModal) window.RAGOrgModal.saveSelectedOrgsToStorage.call(this); },
    setupOrgEditButton() { if (window.RAGOrgModal) window.RAGOrgModal.setupOrgEditButton.call(this); },
    renderOrgBadges() { if (window.RAGOrgModal) window.RAGOrgModal.renderOrgBadges.call(this); },
    openOrgModal() { if (window.RAGOrgModal) window.RAGOrgModal.openOrgModal.call(this); },
    closeOrgModal() { if (window.RAGOrgModal) window.RAGOrgModal.closeOrgModal.call(this); },
    renderModalList() { if (window.RAGOrgModal) window.RAGOrgModal.renderModalList.call(this); },
    updateModalCounts(t) { if (window.RAGOrgModal) window.RAGOrgModal.updateModalCounts.call(this, t); },
    confirmOrgSelection() { if (window.RAGOrgModal) window.RAGOrgModal.confirmOrgSelection.call(this); },


    /**
     * Dosyaları işler ve yükler
     */
    async handleFiles(fileList) {
        if (this.isUploading) {
            this.showToast('Yükleme devam ediyor, lütfen bekleyin...', 'warning');
            return;
        }

        const files = Array.from(fileList);

        // Hedef org seçili mi kontrol et
        if (!this.selectedOrgIds || this.selectedOrgIds.length === 0) {
            // Toast kaldırıldı
            // Dosyaları beklemeye al (Org seçimi sonrası yüklenecek)
            this.pendingFiles = files;
            console.log('[RAGUpload] Pending files set:', this.pendingFiles.length);

            // Org seçim modalını aç
            this.openOrgModal();
            return;
        }

        const supportedExtensions = ['.pdf', '.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt', '.txt'];

        // Dosya validasyonu
        const invalidFiles = files.filter(file => {
            const ext = '.' + file.name.split('.').pop().toLowerCase();
            return !supportedExtensions.includes(ext);
        });

        if (invalidFiles.length > 0) {
            this.showToast(
                `Desteklenmeyen dosya formatı: ${invalidFiles.map(f => f.name).join(', ')}`,
                'error'
            );
            return;
        }

        // Dosya boyutu kontrolü (50MB)
        const maxSize = 50 * 1024 * 1024;
        const largeFiles = files.filter(f => f.size > maxSize);
        if (largeFiles.length > 0) {
            this.showToast(
                `Dosya çok büyük (max 50MB): ${largeFiles.map(f => f.name).join(', ')}`,
                'error'
            );
            return;
        }

        // 🆕 Maturity Score analizi — yüklemeden önce kullanıcıdan onay al
        if (window.MaturityScoreModal) {
            MaturityScoreModal.analyze(
                files,
                (confirmedFiles, scores) => {
                    // Kullanıcı onayladı → skorlarla birlikte yükle
                    this.uploadFiles(confirmedFiles, scores);
                },
                () => {
                    // Kullanıcı iptal etti
                    console.log('[RAGUpload] Kullanıcı yüklemeyi iptal etti (maturity)');
                }
            );
        } else {
            // MaturityScoreModal yüklenmemişse doğrudan yükle
            await this.uploadFiles(files);
        }
    },

    /**
     * Dosyaları sunucuya yükler
     * v2.39.0: Asenkron akış — dosya kaydı senkron, processing arkaplanda.
     * İşlem tamamlanınca WebSocket ile bildirim gelir.
     */
    async uploadFiles(files, maturityScores) {
        this.isUploading = true;
        this.setUploadingState(true);  // UI disable
        this.showProgress(true);
        this.updateProgress(0, 'Dosyalar hazırlanıyor...');

        const formData = new FormData();
        const fileNames = files.map(f => f.name);
        files.forEach(file => {
            formData.append('files', file);
        });

        try {
            this.updateProgress(20, 'Dosyalar yükleniyor...');

            const token = localStorage.getItem('access_token');

            // URL'e org_ids parametresi ekle
            let uploadUrl = `${this.API_BASE}/rag/upload-files`;
            const urlParams = [];
            if (this.selectedOrgIds && this.selectedOrgIds.length > 0) {
                urlParams.push(`org_ids=${this.selectedOrgIds.join(',')}`);
                console.log('[RAGUpload] Uploading with org_ids:', this.selectedOrgIds);
            }
            if (maturityScores && maturityScores.length > 0) {
                urlParams.push(`maturity_scores=${maturityScores.join(',')}`);
                console.log('[RAGUpload] Uploading with maturity_scores:', maturityScores);
            }
            if (urlParams.length > 0) {
                uploadUrl += `?${urlParams.join('&')}`;
            }

            const response = await fetch(uploadUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.detail || 'Yükleme hatası');
            }

            const result = await response.json();

            // v2.39.0: Dosya kaydedildi, processing arkaplanda devam ediyor
            this.updateProgress(100, 'Dosya kaydedildi, işleniyor...');

            // Kısa bildirim — detaylı bildirim WebSocket'ten gelecek
            const fileList = fileNames.length <= 3
                ? fileNames.join(', ')
                : `${fileNames.slice(0, 2).join(', ')} ve ${fileNames.length - 2} dosya daha`;

            if (window.VyraNotification) {
                VyraNotification.info('📄 Dosya İşleniyor', `${fileList} — işlem arkaplanda devam ediyor...`);
            } else {
                this.showToast(`${result.uploaded_count} dosya kaydedildi, işleniyor...`, 'info');
            }

            // Listeyi güncelle — processing durumundaki dosyaları görmek için
            console.log('[RAGUpload] Dosya kaydı başarılı, liste yenileniyor...');
            this.filesCurrentPage = 1;
            await this.loadFiles();
            await this.loadStats();

            // Hedef Org Grupları'nı sıfırla
            this.selectedOrgIds = [];
            sessionStorage.removeItem('rag_selected_org_ids');
            this.renderOrgBadges();

        } catch (error) {
            console.error('[RAGUpload] Yükleme hatası:', error);

            if (window.VyraNotification) {
                VyraNotification.error('Yükleme Hatası', error.message || 'Dosya yüklenirken bir hata oluştu');
            } else {
                this.showToast(error.message || 'Dosya yükleme hatası', 'error');
            }
        } finally {
            this.isUploading = false;
            this.setUploadingState(false);  // UI enable
            setTimeout(() => this.showProgress(false), 1500);

            // File input'u sıfırla
            const fileInput = document.getElementById('rag-file-input');
            if (fileInput) fileInput.value = '';
        }
    },

    // --- FILE LIST ---
    // v2.30.1: modules/rag_file_list.js modülüne taşındı.
    // Delegation: window.RAGFileList
    loadFiles() { if (window.RAGFileList) window.RAGFileList.loadFiles.call(this); },
    renderFilesPagination(t, p, pp) { if (window.RAGFileList) window.RAGFileList.renderFilesPagination.call(this, t, p, pp); },
    goToFilesPage(p) { if (window.RAGFileList) window.RAGFileList.goToFilesPage.call(this, p); },
    updateFilesTotalCount(t) { if (window.RAGFileList) window.RAGFileList.updateFilesTotalCount.call(this, t); },
    onFilesSearchInput(i) { if (window.RAGFileList) window.RAGFileList.onFilesSearchInput.call(this, i); },
    handleFilesSearch() { if (window.RAGFileList) window.RAGFileList.handleFilesSearch.call(this); },
    clearFilesSearch() { if (window.RAGFileList) window.RAGFileList.clearFilesSearch.call(this); },
    loadStats() { if (window.RAGFileList) window.RAGFileList.loadStats.call(this); },
    rebuildVectorstore() { if (window.RAGFileList) window.RAGFileList.rebuildVectorstore.call(this); },
    deleteFile(id, name) { if (window.RAGFileList) window.RAGFileList.deleteFile.call(this, id, name); },
    renderFilesList() { if (window.RAGFileList) window.RAGFileList.renderFilesList.call(this); },
    updateSelectedCount() { if (window.RAGFileList) window.RAGFileList.updateSelectedCount.call(this); },
    getSelectedFileIds() { if (window.RAGFileList) return window.RAGFileList.getSelectedFileIds.call(this); return []; },
    openFile(id) { if (window.RAGFileList) window.RAGFileList.openFile.call(this, id); },
    renderFileRow(f) { if (window.RAGFileList) return window.RAGFileList.renderFileRow.call(this, f); return ''; },
    getFileIconClass(t) { if (window.RAGFileList) return window.RAGFileList.getFileIconClass.call(this, t); return ''; },


    /**
     * Dosya boyutunu formatlar
     */
    formatFileSize(bytes) {
        if (!bytes) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB'];
        let unitIndex = 0;
        let size = bytes;

        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }

        return `${size.toFixed(1)} ${units[unitIndex]}`;
    },

    /**
     * Tarihi formatlar
     */
    formatDate(dateStr) {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('tr-TR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    },

    /**
     * Stats UI'ı günceller
     */
    updateStatsUI(stats) {
        // Backend döner: { total_chunks, embedded_chunks, file_count, storage, embedding_model, embedding_dim }
        const chunkCount = document.getElementById('rag-chunk-count');
        if (chunkCount) {
            // Backend'den gelen doğru field: total_chunks
            chunkCount.textContent = stats.total_chunks || stats.embedded_chunks || 0;
        }

        const statusEl = document.getElementById('rag-status');
        if (statusEl) {
            const hasChunks = (stats.total_chunks || 0) > 0;
            statusEl.textContent = hasChunks ? 'Aktif' : 'Boş';
        }
    },

    /**
     * Dosya sayısını günceller
     */
    updateFileCount(count) {
        const fileCount = document.getElementById('rag-file-count');
        if (fileCount) {
            fileCount.textContent = count || 0;
        }

        const badge = document.querySelector('.files-count-badge');
        if (badge) {
            badge.textContent = count || 0;
        }
    },

    /**
     * Progress bar'ı gösterir/gizler
     */
    showProgress(show) {
        const container = document.querySelector('.upload-progress-container');
        if (container) {
            container.classList.toggle('active', show);
        }
    },

    /**
     * Yükleme sırasında UI elementlerini disable/enable eder
     */
    setUploadingState(isUploading) {
        // Kalem butonu (Org düzenleme)
        const editOrgBtn = document.getElementById('btn-rag-edit-orgs');
        if (editOrgBtn) {
            editOrgBtn.disabled = isUploading;
            editOrgBtn.classList.toggle('disabled', isUploading);
            editOrgBtn.style.pointerEvents = isUploading ? 'none' : '';
            editOrgBtn.style.opacity = isUploading ? '0.5' : '';
        }

        // Drop zone
        const dropZone = document.getElementById('rag-upload-zone');
        if (dropZone) {
            dropZone.classList.toggle('disabled', isUploading);
            dropZone.style.pointerEvents = isUploading ? 'none' : '';
            dropZone.style.opacity = isUploading ? '0.6' : '';
        }

        // File input
        const fileInput = document.getElementById('rag-file-input');
        if (fileInput) {
            fileInput.disabled = isUploading;
        }

        // Rebuild butonu
        const rebuildBtn = document.getElementById('btn-rebuild-vectorstore');
        if (rebuildBtn) {
            rebuildBtn.disabled = isUploading;
        }

        console.log('[RAGUpload] Uploading state:', isUploading ? 'DISABLED' : 'ENABLED');
    },

    /**
     * Progress'i günceller
     */
    updateProgress(percent, text) {
        const fill = document.querySelector('.upload-progress-fill');
        const textEl = document.querySelector('.upload-progress-status');

        if (fill) fill.style.width = `${percent}%`;
        if (textEl) textEl.textContent = text;
    },

    /**
     * Toast mesajı gösterir
     */
    showToast(message, type = 'info') {
        // Global toast fonksiyonu varsa kullan
        if (typeof VyraToast !== 'undefined' && VyraToast[type]) {
            VyraToast[type](message);
        } else if (typeof showToast === 'function') {
            showToast(message, type);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
        // VyraNotification artık doğrudan çağrılıyor - showToast'tan kaldırıldı
    },

    /**
     * HTML escape
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    // --- FILE ORG EDIT ---
    // v2.30.1: modules/rag_file_org_edit.js modülüne taşındı.
    // Delegation: window.RAGFileOrgEdit
    async openFileOrgEditModal(id, name, codes) { if (window.RAGFileOrgEdit) await window.RAGFileOrgEdit.openFileOrgEditModal.call(this, id, name, codes); },
    renderFileOrgModalList() { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.renderFileOrgModalList.call(this); },
    renderFileOrgPagination(tp) { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.renderFileOrgPagination.call(this, tp); },
    updateFileOrgModalCounts(t) { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.updateFileOrgModalCounts.call(this, t); },
    setupFileOrgModalEvents() { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.setupFileOrgModalEvents.call(this); },
    closeFileOrgModal() { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.closeFileOrgModal.call(this); },
    confirmFileOrgEdit() { if (window.RAGFileOrgEdit) window.RAGFileOrgEdit.confirmFileOrgEdit.call(this); },

    // ── Maturity Threshold ──

    /**
     * Maturity iyileştirme eşik değerini API'den yükler
     */
    async loadMaturityThreshold() {
        try {
            const res = await fetch(`${this.API_BASE}/system/maturity-threshold`, {
                headers: { 'Authorization': `Bearer ${localStorage.getItem('access_token')}` }
            });
            if (!res.ok) return;
            const data = await res.json();
            const threshold = data.threshold ?? 80;

            // Slider ve label güncelle
            const slider = document.getElementById('rag-maturity-threshold');
            const label = document.getElementById('rag-threshold-value');
            if (slider) slider.value = threshold;
            if (label) label.textContent = threshold;

            // Global paylaşım (maturity modal okuyacak)
            window._maturityEnhanceThreshold = threshold;
        } catch (err) {
            console.error('[RAGUpload] Threshold yükleme hatası:', err);
            window._maturityEnhanceThreshold = 80;
        }
    },

    /**
     * Maturity iyileştirme eşik değerini API'ye kaydeder
     */
    async saveMaturityThreshold(value) {
        try {
            const res = await fetch(`${this.API_BASE}/system/maturity-threshold?threshold=${value}`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${localStorage.getItem('access_token')}` }
            });
            if (res.ok) {
                window._maturityEnhanceThreshold = value;
                this.showToast(`İyileştirme eşik değeri ${value} olarak güncellendi.`, 'success');
            } else {
                this.showToast('Eşik değeri kaydedilemedi.', 'error');
            }
        } catch (err) {
            console.error('[RAGUpload] Threshold kayıt hatası:', err);
            this.showToast('Eşik değeri kaydedilemedi.', 'error');
        }
    },

};

// Global erişim için
window.RAGUpload = RAGUpload;
