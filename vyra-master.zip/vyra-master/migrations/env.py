"""
VYRA L1 Support API - Alembic Environment Configuration
========================================================
Raw SQL migration modu (SQLAlchemy model kullanmıyor).
Database URL config.py'deki settings'ten okunur.
"""

from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context
import sys
import os

# Proje kök dizinini path'e ekle
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.core.config import settings

# Alembic Config nesnesi (.ini dosyasından)
config = context.config

# Database URL'yi config.py'den oku
config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

# Logging konfigürasyonu
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# SQLAlchemy MetaData yok (raw SQL mode)
target_metadata = None


def run_migrations_offline() -> None:
    """Offline modda migration çalıştır (SQL script üretir)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Online modda migration çalıştır (doğrudan DB'ye uygula)."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
